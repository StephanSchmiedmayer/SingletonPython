from .singleton import singleton
